/*
Uma empresa necessitava criar um sistema para agendamento de reuiniões entre os colaboradores, 
em que estes podem reservar algumas salas da empresa, em determinado dia e horários, para a realização de reuniões 
internass do grupo.

Nome das tabelas : Funcionario e Agendamento
Funcionario (ID, nome, email, cargo)
Agendamento(ID, fx_funcionario, data, local, tipo(comemoração, reunião, etc...))
*/

#Criando o banco de dados
create database Aula3;
#Exibindo os bancos existentes
show databases;
#Colocar o banco em uso
use Aula3;
create table Funcionario(
	ID int auto_increment primary key,
	nome varchar(40),
	email varchar(40),
	cargo varchar(30)
);
#verifica a minha tabela
desc Funcionario;
#Corrigindo informação de uma coluna da minha tabela
alter table Funcionario modify column email varchar(60);

create table Agendamento(
	ID int auto_increment primary key,
	fx_funcionario int,
	data date,
	hora time,
	local varchar(40),
	tipoCompromisso varchar(40),
	foreign key(fx_funcionario) references Funcionario(ID)
);
desc Agendamento;
/*
create table Agendamento(
	ID int auto_increment primary key,
	fx_funcionario int,
	data date,
	hora time,
	local varchar(40),
	tipoCompromisso varchar(40)
);
*/
#Inserindo chave estrangeira na tabela criada
alter table Agendamento
add foreign key(fx_funcionario) references Funcionario(ID);

#Cadastrar S funcionários no banco
insert into Funcionario(nome, email, cargo)
values ('José da Silva','j@gmail.com','Diretor');
insert into Funcionario(nome, email, cargo)
values ('João Rodrigues','joR@gmail.com','Faxineiro');
insert into Funcionario(nome, email, cargo)
values ('Fernando Rosário','fr@gmail.com','Vendedor');
insert into Funcionario(nome, email, cargo)
values ('Diogo Braga','db@gmail.com','Diretor');
insert into Funcionario(nome, email, cargo)
values ('Márcia da Silva','ms@gmail.com','Secretária');
insert into Funcionario
values (NULL, 'Judas Garcia','jg@gmail.com','Estagiário');

#Recuperando os cadastros da tabela funcionários
select * from Funcionario;
select nome, email from Funcionario where id = 4;

#Agendar 5 compromissos data (aaaa--mm--dd), hora (hh:mm)
insert into Agendamento (fx_funcionario,data,hora,local,tipoCompromisso)
values('1','2022-10-20','16:00','Sala 203','Reunião');
insert into Agendamento (fx_funcionario,data,hora,local,tipoCompromisso)
values('2','2022-10-21','17:00','Sala 204','Reunião');
insert into Agendamento (fx_funcionario,data,hora,local,tipoCompromisso)
values('3','2022-10-27','18:00','Sala 207','Comemoração');
insert into Agendamento (fx_funcionario,data,hora,local,tipoCompromisso)
values('4','2022-10-22','16:30','Sala 211','Reunião');
insert into Agendamento (fx_funcionario,data,hora,local,tipoCompromisso)
values('5','2022-10-21','19:00','Sala 205','Comemoração');

#Vereficação dos agendamentos realizados
select * from Agendamento;
#Pegando reuniões da tabela
select * from Agendamento where tipoCompromisso = 'Comemoração';
select * from Agendamento where tipoCompromisso = 'Reunião';
#Vereficar informações dos funcionários que possuem algum agendamento
select nome,cargo from Funcionario, Agendamento
where Funcionario.ID = Agendamento.fx_funcionario;

select nome,cargo,email,data,hora,local from Funcionario, Agendamento
where Funcionario.ID = Agendamento.fx_funcionario;

/*
Exercícios
Utilizar o banco de dados e as tabelas criados para responder as seguintes:
*/

